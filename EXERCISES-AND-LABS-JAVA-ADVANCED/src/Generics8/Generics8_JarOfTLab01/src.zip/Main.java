public class Main {
    public static void main(String[] args) {
        Jar<Integer> jar = new Jar<>();
        jar.add(13);
    }

    public static void print(Object num) {
        System.out.println(num);
    }
}
