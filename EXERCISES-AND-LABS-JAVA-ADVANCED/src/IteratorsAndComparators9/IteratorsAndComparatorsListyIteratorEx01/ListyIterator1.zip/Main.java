import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        List<String> data = Arrays.stream(scanner.nextLine().split("\\s+")).skip(1).collect(Collectors.toList());

        ListyIterator listlyIterator = new ListyIterator(data);

        String input = scanner.nextLine();

        while (!input.equals("END")) {

            switch (input) {
                case "Move":
                    System.out.println(listlyIterator.move());
                    break;
                case "Print":
                    listlyIterator.print();
                    break;
                case "HasNext":
                    System.out.println(listlyIterator.HasNext());
                    break;
            }
            input = scanner.nextLine();
        }
    }
}
