package parking;

import java.util.ArrayList;
import java.util.List;

public class Parking {
    String type;
    int capacity;
    List<Car> data;

    public Parking(String type, int capacity) {
        this.type = type;
        this.capacity = capacity;
        this.data = new ArrayList<>();
    }

    public String getType() {
        return type;
    }

    public void add(Car car) {
        if (data.size() < this.capacity) {
            this.data.add(car);
        }
    }

    public boolean remove(String manufacturer, String model) {
        return this.data.removeIf(car -> car.getModel().equals(model) && car.getManufacturer().equals(manufacturer));
    }
//    •	Method getLatestCar() – returns the latest car (by year) or null if have no cars.
    public Car getLatestCar(){
        return this.data
                .stream()
                .sorted((c1, c2) -> Integer.compare(c2.getYear(), c1.getYear()))
                .findFirst()
                .orElse(null);
    }

    //•	Method getCar(String manufacturer, String model) – returns the car with the given manufacturer and model or null if there is no such car.
    public Car getCar(String manufacturer, String model) {
        return this.data
                .stream()
                .filter(car -> car.getManufacturer().equals(manufacturer) && car.getModel().equals(model))
                .findFirst()
                .orElse(null);
    }

    //•	Getter getCount() – returns the number of cars.
    public int getCount() {
        return this.data.size();
    }

 //•	getStatistics() – returns a String in the following format:
//o	"The cars are parked in {parking type}:
//{Car1}
//{Car2}
//(…)"
    public String getStatistics() {
        StringBuilder output = new StringBuilder();
        output.append("The cars are parked in " + getType() + ":").append(System.lineSeparator());
        this.data.forEach(car -> output.append(car).append(System.lineSeparator()));

        return output.toString().trim();
    }
}
