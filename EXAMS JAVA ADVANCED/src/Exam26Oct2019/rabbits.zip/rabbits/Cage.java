package rabbits;

import java.util.ArrayList;
import java.util.List;


public class Cage {
    private String name;
    private int capacity;
    private List<Rabbit> data;


    public Cage(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.data = new ArrayList<>();

    }

    public String getName() {
        return name;
    }

    public int getCapacity() {
        return capacity;
    }

    public void add(Rabbit rabbit) {
        if (this.data.size() < capacity)
            data.add(rabbit);
    }

    //•	removeRabbit(String name) method - removes a rabbit by given name, if such exists, and returns boolean
    public boolean removeRabbit(String name) {
        Rabbit rabbit = data.stream().filter(s -> s.getName().equals(name)).findFirst().orElse(null);
        if (rabbit != null) {
            data.remove(rabbit);
            return true;
        } else {
            return false;
        }
    }

    //•	removeSpecies(String species) method - removes all rabbits by given species
    public void removeSpecies(String species) {
        Rabbit rabbit = data.stream().filter(s -> s.getSpecies().equals(species)).findFirst().orElse(null);
        if (rabbit != null) {
            data.remove(rabbit);
        }
    }

    //•	sellRabbit(String name) method - sell
// (set its available property to false without removing it from the collection)
// the first rabbit with the given name, also return the rabbit
    public String sellRabbit(String name) {
        StringBuilder sb = new StringBuilder();
        data.stream().filter(rabbit -> rabbit.getName().equals(name)).forEach(rabbit -> rabbit.setAvailable(false));
        for (Rabbit rabbit : data) {
            if (rabbit.getName().equals(name)) {
                sb.append(rabbit);
            }
        }
        //Rabbit (Brazilian): Bunny
        return sb.toString();
    }

    //    •	sellRabbitBySpecies(String species) method - sells and returns all rabbits from that species as a List
    public List<Rabbit> sellRabbitBySpecies(String species) {
        List<Rabbit> soldSpecies = new ArrayList<>();
        data.stream().filter(rabbit -> rabbit.getSpecies().equals(species)).forEach(rabbit -> rabbit.setAvailable(false));
        for (Rabbit rabbit : data) {
            if (rabbit.getSpecies().equals(species)) {
                soldSpecies.add(rabbit);
            }
        }
        //Rabbit (Brazilian): Bunny
        return soldSpecies;
    }

    //      count() - returns the number of rabbits
    public int count() {
        return data.size();
    }

    //•	report() - returns a String in the following format, including only not sold rabbits:
    //o	"Rabbits available at {cageName}:
//{Rabbit 1}
//{Rabbit 2}
//(…)"
    public String report() {
        StringBuilder output = new StringBuilder();
        output.append("Rabbits available at ").append(this.getName()).append(":").append(System.lineSeparator());

        this.data.stream().filter(rabbit -> rabbit.isAvailable()).forEach(rabbit -> output.append(rabbit).append(System.lineSeparator()));

        return output.toString().trim();
    }
}

