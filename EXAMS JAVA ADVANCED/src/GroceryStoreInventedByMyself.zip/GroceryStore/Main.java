package GroceryStore;

public class Main {
    public static void main(String[] args) {

        //Initialize the repository
        Store store = new Store("Kaufland", 7);
        //Initialize entity
        Product firstProduct = new Product("Apple 1kg", "Fruit", 1.50);
//Print Product
        System.out.println(firstProduct); // Product: Apple 1kg, from Fruit category is with price 1.50 lv."
//Add Product
        store.addProduct(firstProduct);

//Remove Product
        System.out.println(store.removeProduct("Product")); //false

//Initialize entities
        Product secondProduct = new Product("Orange 1kg", "Fruit", 1.90);
        Product thirdProduct = new Product("Eggs 10pcs", "Dairy", 2.85);
        Product forthProduct = new Product("Milk 1L", "Dairy", 2.70);
        Product fifthProduct = new Product("Olive Oil 1L", "Cooking Oil", 3.95);
        Product sixthProduct = new Product("Palm Oil 1L", "Cooking Oil", 6.10);

//Add Products
        store.addProduct(secondProduct);
        store.addProduct(thirdProduct);
        store.addProduct(forthProduct);
        store.addProduct(fifthProduct);
        store.addProduct(sixthProduct);

        Product mostExpensiveProduct = store.getMostExpensiveProduct();
        Product productOrange = store.getProduct("Orange 1kg");
        System.out.println(mostExpensiveProduct); // Product: Palm Oil 1L, from Cooking Oil category is with price 6.10 lv."
        System.out.println(productOrange); // Product: Orange 1kg, from Fruit category is with price 1.90 lv."

        System.out.println(store.getCount()); // 6
        System.out.println(store.removeProduct("Milk 1L")); // true


        System.out.println(store.report());
//Products present at Store Kaufland:
//Product: Aplle 1kg, from Fruit category is with price 1.50 lv.
//Product: Orange 1kg, from Fruit category is with price 1.90 lv.
//Product: Eggs 10pcs, from Dairy category is with price 2.85 lv.
//Product: Olive Oil 1L, from Cooking Oil category is with price 3.95 lv."
//Product: Palm Oil 1L, from Cooking Oil category is with price 6.10 lv."
    }
}
