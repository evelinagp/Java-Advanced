package GroceryStore;

import java.util.ArrayList;
import java.util.List;

public class Store {
    private String name;
    private int capacity;
    private List<Product> products;

    public Store(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.products = new ArrayList<>();
    }

    public void addProduct(Product product) {
        if (this.products.size() < this.capacity) {
            this.products.add(product);
        }
    }

    public boolean removeProduct(String name) {
        return this.products.removeIf(p -> p.getName().equals(name));
    }

    public Product getMostExpensiveProduct() {
        return this.products.stream().sorted((p1, p2) -> Double.compare(p2.getPrice(), p1.getPrice()))
                .findFirst().orElse(null);
    }

    public Product getProduct(String name) {
        return this.products.stream().filter(e -> e.getName().equals(name)).findFirst().orElse(null);
    }

    public int getCount() {
        return this.products.size();
    }

    public String report() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("Products present at Store %s:", this.name)).append(System.lineSeparator());
        this.products.forEach(p -> sb.append(p).append(System.lineSeparator()));
        return sb.toString().trim();
    }
}

