package university;

import java.util.ArrayList;
import java.util.List;

    public class University {
        public int capacity;
        public List<Student> students;


        public University(int capacity) {
            this.capacity = capacity;
            this.students = new ArrayList<>();
        }

        public int getCapacity() {
            return this.capacity;
        }

        public List<Student> getStudents() {
            return this.students;
        }


        public int getStudentCount() {
            return this.students.size();
        }

        public String registerStudent(Student student) {
            StringBuilder output = new StringBuilder();
            if (this.students.size() < capacity) {
                if (this.students.contains(student)) {
                    output
                            .append("Student is already in the university");
                } else {
                    this.students.add(student);
                    output.append("Added student ")
                            .append(student.firstName)
                            .append(" ")
                            .append(student.lastName);
                }
            } else {
                output
                        .append("No seats in the university");
            }
            return output.toString();
        }

        public String dismissStudent(Student student) {
            StringBuilder output = new StringBuilder();
            if (this.students.contains(student)) {
                output
                        .append("Removed student ")
                        .append(student.firstName)
                        .append(" ")
                        .append(student.lastName);
                this.students.remove(student);
            } else {
                output
                        .append("Student not found");
            }
            return output.toString();
        }

        public Student getStudent(String firstName, String lastName) {
            return this.students
                    .stream()
                    .filter(student -> student.firstName.equals(firstName) && student.lastName.equals(lastName))
                    .findFirst()
                    .orElse(null);
        }

        public String getStatistics() {
            StringBuilder output = new StringBuilder();
            this.students
                    .forEach(student -> output
                            .append("==Student: First Name = ")
                            .append(student.firstName)
                            .append(", Last Name = ")
                            .append(student.lastName)
                            .append(", Best Subject = ")
                            .append(student.bestSubject)
                            .append(System.lineSeparator()));
            return output.toString().trim();
        }
    }

//    public int capacity;
//    List<Student> students;
////- holds all added students in the university
//
//    public int getCapacity() {
//        return capacity;
//    }
//
//    public List<Student> getStudents() {
//        return students;
//    }
//
//    public University(int capacity) {
//        this.capacity = capacity;
//        this.students = new ArrayList<>();
//
//    }
//
//    //    method– returns the number of students in the university
//    public int getStudentCount() {
//        return students.size();
//    }
//
//    //    adds an entity to the students if there is room for it
////o	Returns "Added student {firstName} {lastName}" if the student is successfully added
////o	Returns "Student is already in the university" if the student is already in the university
////o	Returns "No seats in the university" if the university is full
//    public String registerStudent(Student student) {
//        if (students.contains(student)) {
//            return String.format("Student is already in the university");
//        } else {
//            if (getStudentCount() < this.capacity) {
//                students.add(student);
//                return String.format("Added student %s", student);
//            } else {
//                return String.format("No seats in the university");
//            }
//        }
//    }
//
//    //    •	getStudent(String firstName, String lastName) method - returns the student with the given names.
//    public String getStudent(String firstName, String lastName) {
//        if (students.contains(firstName) && students.contains(lastName)) {
//        }
//        return firstName + ", " + lastName;
//    }
//
//    //        method – removes the student
////    o	Returns "Student not found" if the student is not in the university
//    public String dismissStudent(Student student) {
//        if (students.contains(student)) {
//            students.remove(student);
//        }
//        return String.format("Student not found");
//    }
//
//    //    returns a String in the following format:
//    public String getStatistics( ){
////        return String.format("==Student: First Name = %s, Last Name = %s, Best Subject = %s%n",Student.class.firstName, lastName, subject);
//    }
//}


