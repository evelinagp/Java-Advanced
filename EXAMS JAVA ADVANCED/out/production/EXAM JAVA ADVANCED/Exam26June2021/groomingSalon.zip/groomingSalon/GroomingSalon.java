package groomingSalon;

import java.util.ArrayList;
import java.util.List;

public class GroomingSalon {
    public List<Pet> data;
    public int capacity;
//    •	Field  – List that holds added pets


//    public GroomingSalon(List<String> data) {
//        this.data = new ArrayList<>();
//    }

    public GroomingSalon(int capacity) {
        this.data = new ArrayList<>();
        this.capacity = capacity;
    }

    //    public  List <data>addedPets;
//    – adds an entity to the data if there is an empty place in the grooming salon for the pet.
    public void add(Pet pet) {
        if (data.size() < this.capacity) {
            this.data.add(pet);
        }
    }

    //     – removes the pet by given name, if such exists, and returns boolean.
    public boolean remove(String name) {
        return this.data.removeIf(pet -> pet.getName().equals(name));
    }

    //    returns the pet with the given name and owner or null if no such pet exists.
    public Pet getPet(String name, String owner) {
        return this.data
                .stream()
                .filter(pet -> pet.name.equals(name) && pet.owner.equals(owner))
                .findFirst()
                .orElse(null);
    }

    public int getCount() {
        return this.data.size();
    }

    public String getStatistics() {
        StringBuilder output = new StringBuilder();
        output.append("The grooming salon has the following clients:").append(System.lineSeparator());
        this.data
                .forEach(pet -> output
                        .append(pet.name + " ")
                        .append(pet.owner)
                        .append(System.lineSeparator()));
        return output.toString().trim();
    }
}


